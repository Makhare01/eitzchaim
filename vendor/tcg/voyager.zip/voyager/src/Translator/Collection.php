<?php

namespace TCG\Voyager\Translator;

use Illuminate\Support\Collection as IlluminateCollection;

class Collection extends IlluminateCollection
{
    //
}
