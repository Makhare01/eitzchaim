<?php

namespace TCG\Voyager\Alert\Components;

interface ComponentInterface
{
    public function render();
}
